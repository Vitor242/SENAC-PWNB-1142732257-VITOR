const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

const clientes = [];

// Inclusão de cliente (Método POST)
app.post('/clientes', (req, res) => {
  const novoCliente = req.body;
  novoCliente.id = clientes.length + 1;
  clientes.push(novoCliente);
  res.json(novoCliente);
});

// Ler cliente específico (Método GET)
app.get('/clientes/:id', (req, res) => {
  const cliente = clientes.find(c => c.id === parseInt(req.params.id));
  if (!cliente) {
    return res.status(404).json({ mensagem: 'Cliente não encontrado' });
  }
  res.json(cliente);
});

// Lista de todos os clientes (Método GET)
app.get('/clientes', (req, res) => {
  res.json(clientes);
});

// Alteração de cliente (Método PUT)
app.put('/clientes/:id', (req, res) => {
  const clienteIndex = clientes.findIndex(c => c.id === parseInt(req.params.id));
  if (clienteIndex === -1) {
    return res.status(404).json({ mensagem: 'Cliente não encontrado' });
  }

  clientes[clienteIndex] = { ...clientes[clienteIndex], ...req.body };
  res.json(clientes[clienteIndex]);
});

app.delete('/clientes/:id', (req, res) => {
  const clienteIndex = clientes.findIndex(c => c.id === parseInt(req.params.id));
  if (clienteIndex !== -1) {
    const clienteExcluido = clientes.splice(clienteIndex, 1);
    res.json(clienteExcluido[0]);
  } else {
    res.sendStatus(204); 
  }
});
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});